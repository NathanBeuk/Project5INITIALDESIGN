/**
 * Description
 * @author Adoniram Courser and Nathan Beukema
 * @version 1.0
 * @since 11-29-23
 */
public class Game {
    /**
     * main method
     * @param args
     */
    public static void main(String[] args) {
    }
}